# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.16.4
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# # Modeling: Revolving a sketch
#
# This example shows how to use the ``revolve_sketch()`` method to
# revolve a sketch around an axis to create a 3D body. You can also
# specify the angle of revolution to create a partial body.

# Imports
from ansys.geometry.core import launch_modeler
from ansys.geometry.core.math import (
  Plane,
  Point2D,
  Point3D,
  UNITVECTOR3D_X,
  UNITVECTOR3D_Z,
)
from ansys.geometry.core.misc import UNITS, Angle
from ansys.geometry.core.sketch import Sketch


# ## Initialize the modeler

# Initialize the modeler for this example notebook
m = launch_modeler()
print(m)

# ## Example: Creating a quarter of a donut
#
# The following code snippets show how to use the ``revolve_sketch()`` function to create a
# quarter of a 3D donut. The process involves defining a quarter of a circle as a profile
# and then revolving it around the Z-axis to create a 3D body.
#
# ### Initialize the sketch design
#
# Create a design sketch named ``quarter-donut``.

# Initialize the donut sketch design
design = m.create_design("quarter-donut")

# ### Define circle parameters
#
# Set ``path_radius``, which represents the radius of the circular path that the profile
# circle sweeps along, to ``5`` units.
# Set ``profile_radius``, which represents the radius of the profile circle that sweeps
# along the path to create the donut body, to ``2`` units.

# Donut parameters
path_radius = 5
profile_radius = 2

# ### Create the profile circle
#
# Create a circle on the XZ plane centered at the coordinates ``(5, 0, 0)``
# and use``profile_radius`` to define the radius. This circle serves as the
# profile or cross-sectional shape of the donut.

# +
# Create the circular profile on the XZ-plane centered at (5, 0, 0)
# with a radius of 2
plane_profile = Plane(
    origin=Point3D([path_radius, 0, 0]),
    direction_x=UNITVECTOR3D_X,
    direction_y=UNITVECTOR3D_Z,
)
profile = Sketch(plane=plane_profile)
profile.circle(Point2D([0, 0]), profile_radius)

profile.plot()
# -

# ### Perform the revolve operation
#
# Revolve the profile circle around the Z axis to create a quarter of a donut body.
# Set the angle of revolution to 90 degrees in the default direction, which is counterclockwise.

# +
# Revolve the profile around the Z axis and center in the absolute origin
# for an angle of 90 degrees
design.revolve_sketch(
    "quarter-donut-body",
    sketch=profile,
    axis=UNITVECTOR3D_Z,
    angle=Angle(90, unit=UNITS.degrees),
    rotation_origin=Point3D([0, 0, 0]),
)

design.plot()
# -

# ### Perform a revolve operation with a negative angle of revolution
#
# You can use a negative angle of revolution to create a quarter of a donut in the opposite direction. The following code snippet shows how to create a quarter of a donut in the clockwise direction. The same profile circle is used, but the angle of revolution is set to -90 degrees.

# +
# Initialize the donut sketch design
design = m.create_design("quarter-donut-negative")

# Revolve the profile around the Z axis and center in the absolute origin
# for an angle of -90 degrees (clockwise)
design.revolve_sketch(
    "quarter-donut-body-negative",
    sketch=profile,
    axis=UNITVECTOR3D_Z,
    angle=Angle(-90, unit=UNITS.degrees),
    rotation_origin=Point3D([0, 0, 0]),
)

design.plot()
# -

# ## Close the modeler

# Close the modeler
m.close()
