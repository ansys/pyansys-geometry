# ---
# jupyter:
#   jupytext:
#     default_lexer: ipython3
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.17.3
#   kernelspec:
#     display_name: Python 3 (ipykernel)
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Modeling: Tessellation of two bodies
#
# This example shows how to create two stacked bodies and return the tessellation
# as two merged bodies.

# %% [markdown]
# ## Perform required imports
#
# Perform the required imports.

# %%
from pint import Quantity

from ansys.geometry.core import launch_modeler
from ansys.geometry.core.math import Point2D, Point3D, Plane
from ansys.geometry.core.misc import UNITS
from ansys.geometry.core.sketch import Sketch


# %% [markdown]
# ## Create design
#
# Create the basic sketches to be tessellated and extrude the sketch in the
# required plane. For more information on creating a component and extruding a
# sketch in the design, see the [Rectangular plate with multiple bodies](plate_with_hole.mystnb)
# example.
#
# Here is a typical situation in which two bodies, with different sketch planes,
# merge each body into a single dataset. This effectively combines all the faces
# of each individual body into a single dataset without separating faces.

# %%
modeler = launch_modeler()

sketch_1 = Sketch()
box = sketch_1.box(
    Point2D([10, 10], unit=UNITS.m), width=Quantity(10, UNITS.m), height=Quantity(5, UNITS.m)
)
circle = sketch_1.circle(
    Point2D([0, 0], unit=UNITS.m), radius=Quantity(25, UNITS.m)
)

design = modeler.create_design("TessellationDesign")
comp = design.add_component("TessellationComponent")
body = comp.extrude_sketch("Body", sketch=sketch_1, distance=10 * UNITS.m)

# Create the second body in a plane with a different origin
sketch_2 = Sketch(Plane([0, 0, 10]))
box = sketch_2.box(Point2D(
    [10, 10], unit=UNITS.m), width=Quantity(10, UNITS.m), height=Quantity(5, UNITS.m)
)
circle = sketch_2.circle(
    Point2D([0, 10], unit=UNITS.m), radius=Quantity(25, UNITS.m)
)

body = comp.extrude_sketch("Body", sketch=sketch_2, distance=10 * UNITS.m)

# %% [markdown]
# ## Tessellate component as two merged bodies
#
# Tessellate the component and merge each body into a single dataset. This effectively
# combines all the faces of each individual body into a single dataset without
# separating faces.

# %%
dataset = comp.tessellate()
dataset

# %% [markdown]
# Single body tessellation is possible. In that case, users can request the body-level tessellation
# method to tessellate the body and merge all the faces into a single dataset.

# %%
dataset = comp.bodies[0].tessellate()
dataset

# %% [markdown]
# ## Plot design
#
# Plot the design.

# %%
design.plot()

# %% [markdown]
# ## Close the modeler
#
# Close the modeler.

# %%
modeler.close()
